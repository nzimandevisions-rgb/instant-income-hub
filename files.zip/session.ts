import { useEffect, useState } from "react";

// Module-scoped so every component mounted on the same page share one
// in-flight request instead of racing to create two different sessions.
let sessionPromise: Promise<string> | null = null;

async function startSession(): Promise<string> {
  const res = await fetch("/api/user/session", { method: "POST" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.accountId) throw new Error(data.error || "Unable to start wallet session.");
  if (typeof window !== "undefined") {
    // Kept for display/debugging only — the httpOnly session cookie set by
    // /api/user/session is what actually ties requests to this account.
    window.localStorage.setItem("syde_hustle_account_id", data.accountId);
  }
  return data.accountId as string;
}

/**
 * Establishes (or reuses) the server-backed wallet session and returns the
 * account id it's tied to. This is the SAME id balance/withdraw/postback
 * endpoints resolve from the session cookie — use it anywhere an offer
 * tracking id or the user's account id needs to be shown or sent.
 */
export function useAccountSession() {
  const [accountId, setAccountId] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    if (!sessionPromise) sessionPromise = startSession();
    sessionPromise
      .then((id) => {
        if (active) setAccountId(id);
      })
      .catch((err) => {
        sessionPromise = null; // allow a retry on next mount/render
        if (active) setError(err instanceof Error ? err.message : "Session failed");
      });
    return () => {
      active = false;
    };
  }, []);

  return { accountId, error };
}
