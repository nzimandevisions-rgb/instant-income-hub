import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useFeed, type LiveTask } from "@/lib/feed";
import { ensureSession } from "@/lib/account";

export const Route = createFileRoute("/")({ component: DashboardPage });

function TaskCard({ task, onStart }: { task: LiveTask; onStart: (task: LiveTask) => void }) {
  return (
    <article className="group overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/90 transition hover:-translate-y-0.5 hover:border-emerald-500/30 hover:shadow-xl">
      <div className="flex flex-col sm:flex-row">
        <div className="relative h-44 w-full shrink-0 overflow-hidden bg-gradient-to-br from-slate-800 to-slate-950 sm:h-auto sm:w-48">
          {task.imageUrl ? (
            <img
              src={task.imageUrl}
              alt=""
              loading="lazy"
              className="h-full min-h-36 w-full object-cover transition duration-300 group-hover:scale-105"
              onError={(event) => { event.currentTarget.style.display = "none"; }}
            />
          ) : (
            <div className="flex h-full min-h-36 items-center justify-center text-4xl">🎁</div>
          )}
          <div className="absolute left-3 top-3 rounded-full bg-slate-950/80 px-2.5 py-1 text-[10px] font-black uppercase text-emerald-300 backdrop-blur">
            {task.hot ? "🔥 HOT" : "LIVE"}
          </div>
        </div>
        <div className="flex min-w-0 flex-1 flex-col justify-between gap-4 p-5 sm:flex-row sm:items-center">
          <div className="min-w-0">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              {task.meta && <span className="rounded-md bg-slate-800 px-2 py-1 text-[10px] font-bold uppercase text-slate-400">{task.meta}</span>}
              <span className="rounded-lg bg-emerald-500/10 px-2.5 py-1 font-mono text-xs font-black text-emerald-400">
                +{task.points.toLocaleString()} PTS
              </span>
            </div>
            <h3 className="line-clamp-2 text-base font-bold text-white">{task.title}</h3>
            {task.description && <p className="mt-1 line-clamp-3 text-xs leading-5 text-slate-400">{task.description}</p>}
          </div>
          <button
            type="button"
            disabled={!task.url}
            onClick={() => task.url && onStart(task)}
            className="shrink-0 rounded-xl bg-emerald-500 px-4 py-2.5 text-xs font-black text-slate-950 transition hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500"
          >
            {task.url ? "Start & Earn →" : "Unavailable"}
          </button>
        </div>
      </div>
    </article>
  );
}

function DashboardPage() {
  const [id, setId] = useState("");
  const [tab, setTab] = useState<"all" | "offer" | "survey">("all");
  const [activeTask, setActiveTask] = useState<LiveTask | null>(null);

  useEffect(() => {
    ensureSession()
      .then((session) => setId(session.accountId))
      .catch(() => undefined);
  }, []);

  const offers = useFeed("offer", id);
  const surveys = useFeed("survey", id);
  const tasks =
    tab === "offer"
      ? offers.tasks
      : tab === "survey"
        ? surveys.tasks
        : [...offers.tasks, ...surveys.tasks];

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-3xl border border-emerald-500/20 bg-gradient-to-br from-slate-900 to-emerald-950/50 p-6 sm:p-8">
        <div className="relative">
          <div className="mb-3 inline-flex rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-emerald-300">
            ● Earn points from completed tasks
          </div>
          <h1 className="text-2xl font-black text-white sm:text-3xl">Complete offers. Build your balance.</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">
            Complete tasks inside Syde Hustle. Your account ID is used for approved tracking and confirmed completions are credited automatically.
          </p>
          <p className="mt-4 font-mono text-xs text-slate-500">
            Account ID: <span className="text-emerald-400">{id || "Creating account..."}</span>
          </p>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">Available tasks</p>
            <h2 className="mt-1 text-xl font-black text-white">Earn by completing tasks</h2>
          </div>
          <div className="flex rounded-xl border border-slate-800 bg-slate-900 p-1">
            {(["all", "offer", "survey"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setTab(item)}
                className={
                  tab === item
                    ? "rounded-lg bg-emerald-500 px-3 py-2 text-[11px] font-bold capitalize text-slate-950"
                    : "rounded-lg px-3 py-2 text-[11px] font-bold capitalize text-slate-400"
                }
              >
                {item === "all" ? "All" : item + "s"}
              </button>
            ))}
          </div>
        </div>

        {(offers.loading || surveys.loading) && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 text-center text-sm text-slate-400">
            Loading available tasks…
          </div>
        )}

        {!(offers.loading || surveys.loading) && tasks.length === 0 && (
          <div className="rounded-2xl border border-dashed border-slate-700 bg-slate-900/50 p-6 text-center text-sm text-slate-400">
            No eligible tasks are available right now. New tasks will appear automatically when an approved feed has eligible inventory.
          </div>
        )}

        {(offers.error || surveys.error) && (
          <p className="text-xs text-amber-300">Some task inventory is temporarily unavailable. Please check back shortly.</p>
        )}

        <div className="space-y-3">
          {tasks.map((task) => (
            <TaskCard key={task.id + task.title} task={task} onStart={setActiveTask} />
          ))}
        </div>
      </section>

      {activeTask?.url && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 p-2 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-label="Syde Hustle task"
        >
          <div className="flex h-[96vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl">
            <div className="flex items-center justify-between gap-3 border-b border-slate-800 px-4 py-3">
              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">Syde Hustle Task</p>
                <h2 className="truncate text-sm font-bold text-white">{activeTask.title}</h2>
              </div>
              <button type="button" onClick={() => setActiveTask(null)} className="rounded-lg bg-slate-800 px-3 py-2 text-xs font-bold text-white hover:bg-slate-700">
                Close
              </button>
            </div>
            <iframe
              title="Syde Hustle task"
              src={activeTask.url}
              className="min-h-0 flex-1 bg-white"
              sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-scripts allow-same-origin"
              referrerPolicy="strict-origin-when-cross-origin"
            />
            <div className="border-t border-slate-800 px-4 py-2 text-center text-[10px] text-slate-500">
              Complete the task in this Syde Hustle window. Rewards are credited only after a confirmed completion.
            </div>
          </div>
        </div>
      )}

      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="font-bold text-white">Ready to cash out?</h2>
            <p className="mt-1 text-xs text-slate-400">
              Balances refresh automatically after confirmed completions. Cash out to PayPal from
              your wallet once you reach 500 PTS.
            </p>
          </div>
          <Link to="/wallet" className="rounded-xl border border-emerald-500/40 px-4 py-2 text-xs font-bold text-emerald-300">
            View wallet
          </Link>
        </div>
      </section>

      <p className="text-center text-[11px] text-slate-600">
        1,000 points = $1.00 USD. Third-party networks control approval and completion.
      </p>
    </div>
  );
}
