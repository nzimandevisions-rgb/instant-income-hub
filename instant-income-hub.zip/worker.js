export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // =====================================================================
    // 1. POSTBACK HANDLER: Credits points when user finishes a job/survey
    // =====================================================================
    if (url.pathname === "/api/postback") {
<<<<<<< HEAD
      // Extract parameters sent by Adscend / AdGem / Digital Turbine / CPALead
      const subId = url.searchParams.get("subId") || 
                    url.searchParams.get("subid1") || 
                    url.searchParams.get("user_id") || 
                    url.searchParams.get("playerid") || 
                    url.searchParams.get("uid");

      const reward = parseInt(
        url.searchParams.get("reward") || 
        url.searchParams.get("points") || 
        url.searchParams.get("amount") || "0",
        10
      );

      const txid = url.searchParams.get("txid") || 
                   url.searchParams.get("trans_id") || 
                   `tx_${Date.now()}`;

      // Check for valid inputs
      if (!subId || isNaN(reward) || reward <= 0) {
        return new Response("Missing subId or valid reward amount", { status: 400 });
=======
      const params = new URLSearchParams(url.search);
      if (request.method === "POST") {
        const body = await request.text();
        if (body) new URLSearchParams(body).forEach((value, key) => params.set(key, value));
      }
      const subId = params.get("subid") || params.get("subId") || params.get("subid1") ||
                    params.get("user_id") || params.get("playerid") || params.get("uid");
      const reward = Number(params.get("payout") || params.get("reward") || params.get("points") || params.get("amount"));
      const txid = params.get("txid") || params.get("transaction_id") || params.get("trans_id") || params.get("conversion_id");

      if (!subId || !/^[A-Za-z0-9._:@-]{3,128}$/.test(subId)) {
        return new Response("Missing or invalid subid", { status: 400 });
      }
      if (!Number.isFinite(reward) || reward <= 0 || !Number.isSafeInteger(reward)) {
        return new Response("Missing or invalid payout", { status: 400 });
      }
      if (!txid || !/^[A-Za-z0-9._:@-]{1,200}$/.test(txid)) {
        return new Response("Missing conversion ID", { status: 400 });
>>>>>>> 88ead9c (feat: add new dashboard page with user balance and task tracking)
      }

      if (!env.DB) {
        return new Response("D1 database binding missing on Cloudflare", { status: 500 });
      }

      try {
<<<<<<< HEAD
        // Look up the user by ID or Email
        let user = await env.DB.prepare(
          "SELECT id, points FROM users WHERE id = ? OR email = ?"
        ).bind(subId, subId).first();

        let targetId = subId;

        if (!user) {
          // If the user doesn't exist yet, auto-register them with the reward
          targetId = `usr_${Date.now()}`;
          await env.DB.prepare(
            "INSERT INTO users (id, email, points) VALUES (?, ?, ?)"
          ).bind(targetId, subId.includes("@") ? subId : `${subId}@user.sydehustle.com`, reward).run();
        } else {
          // Increment the existing user's points
          targetId = user.id;
          await env.DB.prepare(
            "UPDATE users SET points = points + ? WHERE id = ?"
          ).bind(reward, user.id).run();
        }

        // Save transaction history so users have proof of work
        await env.DB.prepare(
          "INSERT OR IGNORE INTO transactions (id, user_id, amount, txid, type) VALUES (?, ?, ?, ?, 'job_reward')"
        ).bind(`txn_${Date.now()}`, targetId, reward, txid).run();

        // Ad networks require plain HTTP 200 "OK"
        return new Response("OK", { status: 200 });
      } catch (err) {
        return new Response(`Database error: ${err.message}`, { status: 500 });
=======
        const existing = await env.DB.prepare(
          "SELECT txid FROM transactions WHERE txid = ? LIMIT 1"
        ).bind(txid).first();
        if (existing) return new Response("OK", { status: 200 });

        const user = await env.DB.prepare(
          "SELECT id FROM users WHERE id = ? OR email = ? LIMIT 1"
        ).bind(subId, subId).first();
        if (!user) return new Response("Unknown user", { status: 404 });

        await env.DB.batch([
          env.DB.prepare("UPDATE users SET points = points + ? WHERE id = ?").bind(reward, user.id),
          env.DB.prepare(
            "INSERT INTO transactions (id, user_id, amount, txid, type) VALUES (?, ?, ?, ?, 'job_reward')"
          ).bind(`txn_${crypto.randomUUID()}`, user.id, reward, txid),
        ]);

        // Ad networks require plain HTTP 200 "OK"
        return new Response("OK", { status: 200 });
      } catch {
        return new Response("Unable to process postback", { status: 500 });
>>>>>>> 88ead9c (feat: add new dashboard page with user balance and task tracking)
      }
    }

    // =====================================================================
    // 2. USER BALANCE HANDLER: Returns the current points balance
    // =====================================================================
    if (url.pathname === "/api/user/balance") {
      const userIdentifier = url.searchParams.get("user");
      if (!userIdentifier || !env.DB) {
        return new Response(JSON.stringify({ points: 0 }), {
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }

      const user = await env.DB.prepare(
        "SELECT id, email, points FROM users WHERE id = ? OR email = ?"
      ).bind(userIdentifier, userIdentifier).first();

      return new Response(JSON.stringify(user || { points: 0 }), {
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }

    // =====================================================================
    // 3. FRONTEND HANDLER: Serves your website pages
    // =====================================================================
    if (env.ASSETS) {
      return await env.ASSETS.fetch(request);
    }

    return new Response("Site assets not found", { status: 404 });
  }
};
