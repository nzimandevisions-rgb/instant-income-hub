import { createAPIFileRoute } from '@tanstack/start/api'

export const Route = createAPIFileRoute('/api/postback')({
  GET: async ({ request }) => handlePostback(request),
  POST: async ({ request }) => handlePostback(request),
})

async function handlePostback(request: Request) {
  const url = new URL(request.url)
<<<<<<< HEAD

  const subId = url.searchParams.get('subId') ||
                url.searchParams.get('subid1') ||
                url.searchParams.get('user_id') ||
                url.searchParams.get('playerid') ||
                url.searchParams.get('uid')

  const reward = parseInt(
    url.searchParams.get('reward') ||
    url.searchParams.get('points') ||
    url.searchParams.get('amount') || '0',
    10
  )

  const txid = url.searchParams.get('txid') ||
               url.searchParams.get('trans_id') ||
               `tx_${Date.now()}`

  if (!subId || isNaN(reward) || reward <= 0) {
    return new Response('Missing subId or valid reward amount', { status: 400 })
=======
  const params = new URLSearchParams(url.search)

  if (request.method === 'POST') {
    const body = await request.text()
    if (body) new URLSearchParams(body).forEach((value, key) => params.set(key, value))
  }

  const subId = params.get('subid') || params.get('subId') || params.get('subid1') ||
    params.get('user_id') || params.get('playerid') || params.get('uid')
  const rewardValue = params.get('payout') || params.get('reward') || params.get('points') || params.get('amount')
  const reward = Number(rewardValue)
  const txid = params.get('txid') || params.get('transaction_id') || params.get('trans_id') || params.get('conversion_id')

  if (!subId || !/^[A-Za-z0-9._:@-]{3,128}$/.test(subId)) {
    return new Response('Missing or invalid subid', { status: 400 })
  }
  if (!Number.isFinite(reward) || reward <= 0 || !Number.isSafeInteger(reward)) {
    return new Response('Missing or invalid payout', { status: 400 })
  }
  if (!txid || !/^[A-Za-z0-9._:@-]{1,200}$/.test(txid)) {
    return new Response('Missing conversion ID', { status: 400 })
>>>>>>> 88ead9c (feat: add new dashboard page with user balance and task tracking)
  }

  // Access Cloudflare D1 Database binding via global or request env
  const env = (process as any).env?.DB ? (process as any).env : (globalThis as any).__env__ || (globalThis as any)
  const db = env?.DB

  if (!db) {
    return new Response('D1 Database binding missing in Cloudflare', { status: 500 })
  }

  try {
<<<<<<< HEAD
    let user = await db.prepare(
      'SELECT id, points FROM users WHERE id = ? OR email = ?'
    ).bind(subId, subId).first()

    let targetId = subId

    if (!user) {
      targetId = `usr_${Date.now()}`
      await db.prepare(
        'INSERT INTO users (id, email, points) VALUES (?, ?, ?)'
      ).bind(targetId, subId.includes('@') ? subId : `${subId}@user.sydehustle.com`, reward).run()
    } else {
      targetId = user.id
      await db.prepare(
        'UPDATE users SET points = points + ? WHERE id = ?'
      ).bind(reward, user.id).run()
    }

    await db.prepare(
      'INSERT OR IGNORE INTO transactions (id, user_id, amount, txid, type) VALUES (?, ?, ?, ?, ?)'
    ).bind(`txn_${Date.now()}`, targetId, reward, txid, 'job_reward').run()
=======
    const existing = await db.prepare(
      'SELECT txid FROM transactions WHERE txid = ? LIMIT 1'
    ).bind(txid).first()
    if (existing) return new Response('OK', { status: 200 })

    const user = await db.prepare(
      'SELECT id FROM users WHERE id = ? OR email = ? LIMIT 1'
    ).bind(subId, subId).first() as { id: string } | null
    if (!user) return new Response('Unknown user', { status: 404 })

    await db.batch([
      db.prepare('UPDATE users SET points = points + ? WHERE id = ?').bind(reward, user.id),
      db.prepare(
        'INSERT INTO transactions (id, user_id, amount, txid, type) VALUES (?, ?, ?, ?, ?)'
      ).bind(`txn_${crypto.randomUUID()}`, user.id, reward, txid, 'job_reward'),
    ])
>>>>>>> 88ead9c (feat: add new dashboard page with user balance and task tracking)

    return new Response('OK', { 
      status: 200,
      headers: { 'Content-Type': 'text/plain' }
    })
<<<<<<< HEAD
  } catch (err: any) {
    return new Response(`Database error: ${err.message}`, { status: 500 })
=======
  } catch {
    return new Response('Unable to process postback', { status: 500 })
>>>>>>> 88ead9c (feat: add new dashboard page with user balance and task tracking)
  }
}
